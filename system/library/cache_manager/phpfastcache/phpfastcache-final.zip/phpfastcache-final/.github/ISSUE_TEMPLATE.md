###Configuration:

PhpFastCache version: ` ...replace me... `
PHP version: ` ...replace me... `
Operating system: ` ...replace me... `

####Issue description:

> ...Your description goes here...